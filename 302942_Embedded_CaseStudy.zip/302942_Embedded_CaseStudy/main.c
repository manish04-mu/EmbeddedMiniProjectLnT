#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "lcd.h"
#include "adc.h"
#include "temperature.h"
#include "button.h"

int main()
{
    EICRA|=(1 << ISC00);  //Interrupt 0: any logical change
    EICRA|=(1 << ISC10);  //Interrupt 1: any logical change
    EIMSK|=(1 << INT0);   //Initialize Interrupt 0
    EIMSK|=(1 << INT1);   //Initialize Interrupt 1
    sei();                //Initialize global interrupt

    TCCR0A|=(1<<COM0A1)|(1<<WGM00)|(1<<WGM01);
    TCCR0B|=(1<<CS01)|(1<<CS00);
    DDRD|=(1<<PD6);
    InitADC();
    LCD_Init();
    uint16_t volatile temps;

    while(1)
    {
        buttonSensor();
        temps = ReadADC(0);
        _delay_ms(200);
        temperatureSensor(temps);
    }
    return 0;
}
