#include <avr/io.h>
#ifndef TEMPERATURE_H
#define TEMPERATURE_H
void temperatureCoversion(int temp)
{
    if ((temp>10)&(temp<64))
    {
        LCD_String("Temp: ");
        LCD_String("21");	/* Write string on 1st line of LCD*/
    }
    else if ((temp>=64) & (temp<128))
    {
        LCD_String("Temp: ");
        LCD_String("22");
    }
    else if ((temp>=128) & (temp<192))
    {
        LCD_String("Temp: ");
        LCD_String("23");
    }
    else if ((temp>=192) & (temp<256))
    {
        LCD_String("Temp: ");
        LCD_String("24");
    }
    else if ((temp>=256) & (temp<320))
    {
        LCD_String("Temp: ");
        LCD_String("25");
    }
    else if ((temp>=320) & (temp<384))
    {
        LCD_String("Temp: ");
        LCD_String("26");
    }
    else if ((temp>=384) & (temp<448))
    {
        LCD_String("Temp: ");
        LCD_String("27");
    }
    else if ((temp>=448) & (temp<512))
    {
        LCD_String("Temp: ");
        LCD_String("28");
    }
    else if ((temp>=512) & (temp<576))
    {
        LCD_String("Temp: ");
        LCD_String("29");
    }
    else if ((temp>=576) & (temp<640))
    {
        LCD_String("Temp: ");
        LCD_String("30");
    }
    else if ((temp>=640) & (temp<704))
    {
        LCD_String("Temp: ");
        LCD_String("31");
    }
    else if ((temp>=704) & (temp<768))
    {
        LCD_String("Temp: ");
        LCD_String("32");
    }
    else if ((temp>=768) & (temp<832))
    {
        LCD_String("Temp: ");
        LCD_String("33");
    }
    else if ((temp>=832) & (temp<896))
    {
        LCD_String("Temp: ");
        LCD_String("34");
    }
    else if ((temp>=896) & (temp<968))
    {
        LCD_String("Temp: ");
        LCD_String("35");
    }
    else if ((temp>=968) & (temp<1024))
    {
        LCD_String("Temp: ");
        LCD_String("36");
    }
    else
    {
        LCD_Clear();
    }
}

void generatePwm(int x)  //generate PWM based on temp value
{
    OCR0A = x/4;
    _delay_ms(20);
}

void temperatureSensor(uint16_t temp)
{
    DDRC |= (1 << PC5);
    DDRC |= (1 << PC4);
    DDRC |= (1 << PC3);
    DDRC |= (1 << PC2);

    if ((temp>10) & (temp<256))
    {
        temperatureCoversion(temp);    //write temperature on the LCD
        LCD_Command(0x80);
        generatePwm(temp);
        PORTC = 0x04;
    }
    else if ((temp>=256) & (temp<512))
    {
        temperatureCoversion(temp);
        LCD_Command(0x80);
        generatePwm(temp);
        PORTC = 0x0C;
    }
    else if ((temp>=512) & (temp<768))
    {
        temperatureCoversion(temp);
        LCD_Command(0x80);
        generatePwm(temp);
        PORTC = 0x1C;
    }
    else if ((temp>=768) &(temp<1024))
    {
        temperatureCoversion(temp);
        LCD_Command(0x80);
        generatePwm(temp);
        PORTC = 0x3C;
    }
    else
    {
        temperatureCoversion(temp);
        LCD_Command(0x80);
        generatePwm(temp);
        PORTC = 0x00;
    }
}

#endif
