#ifndef BUTTON_H
#define BUTTON_H

#define LED PD1
#define TEMP_KNOB PC1
#define I0 PD2
#define I1 PD3

unsigned volatile FLAG1 = 0;
unsigned volatile FLAG2 = 0;

ISR(INT0_vect)
{
    FLAG1=(FLAG1 ^ 1);
}

ISR (INT1_vect)
{
    FLAG2=(FLAG2 ^ 1);
}

void buttonSensor()
{
    DDRD |= (1 << LED);   //set port LED to output mode
    DDRC |= (1 << TEMP_KNOB); // set port KNOB to output mode
    DDRD &= ~(1 << I0);   // set port INT0 to input mode
    PORTD |= (1 << I0);   // set bit
    DDRD &= ~(1 << I1);   // set port INT1 to input mode
    PORTD |= (1 << I1);   // set bit
    if ((FLAG1==1) & (FLAG2==1))
    {
        PORTD |= (1 << LED);    //set value of port LED as high
        PORTC |= (1 << TEMP_KNOB);   //set value of port KNOB as high
    }
    else if ((FLAG1==0) & (FLAG2==0))
    {
        PORTD &= ~(1 << LED);   //set value of port LED as low
        PORTC &= ~(1 << TEMP_KNOB); //set value of port KNOB as low
    }
}
#endif // BUTTON_H
